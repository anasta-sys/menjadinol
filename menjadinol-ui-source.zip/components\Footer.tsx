export function Footer() {
  return (
    <>
      <footer className="site-footer proper-footer">
        <div className="footer-inner">
          <div className="footer-mark" aria-hidden="true">
            N
          </div>

          <div className="footer-center">
            <p className="footer-sentence">
              Ruang untuk berjeda, menyelami rasa, memahami makna, dan kembali pada diri.
            </p>

            <div className="footer-meta">
              <span>Spiritual Journey by Anasta</span>
              <span className="dot">•</span>
              <span>Privacy-first</span>
              <span className="dot">•</span>
              <span>no third-party trackers</span>
              <span className="dot">•</span>
              <span>© {new Date().getFullYear()}</span>
            </div>
          </div>

          <div className="footer-spacer" aria-hidden="true" />
        </div>
      </footer>

      <style>{`
        .site-footer.proper-footer {
          position: relative;
          z-index: 30;

          width: calc(100% - 28px);
          min-height: 104px;

          margin:
            18px
            14px
            18px;

          padding:
            18px
            24px;

          box-sizing: border-box;

          display: flex;
          align-items: center;
          justify-content: center;

          border:
            1px solid
            rgba(62, 78, 64, 0.14);

          border-radius: 18px;

          background:
            rgba(248, 244, 235, 0.98);

          box-shadow:
            0 8px 28px
            rgba(66, 72, 63, 0.055);

          overflow: visible;
        }

        .site-footer.proper-footer .footer-inner {
          width: 100%;
          max-width: 1440px;

          display: grid;
          grid-template-columns:
            44px
            minmax(0, 1fr)
            44px;

          align-items: center;
          gap: 18px;
        }

        .site-footer.proper-footer .footer-mark {
          width: 36px;
          height: 36px;

          display: flex;
          align-items: center;
          justify-content: center;

          border-radius: 50%;

          background: #343835;
          color: #f8f5ec;

          font-family:
            Georgia,
            "Times New Roman",
            serif;

          font-size: 14px;
          line-height: 1;

          box-shadow:
            0 2px 8px
            rgba(35, 40, 36, 0.14);
        }

        .site-footer.proper-footer .footer-center {
          min-width: 0;
          text-align: center;
        }

        .site-footer.proper-footer .footer-sentence {
          margin: 0;

          color: #29412f;

          font-family:
            Georgia,
            "Times New Roman",
            serif;

          font-size:
            clamp(
              15px,
              1.25vw,
              19px
            );

          font-weight: 400;
          line-height: 1.4;
        }

        .site-footer.proper-footer .footer-meta {
          margin-top: 8px;

          display: flex;
          flex-wrap: wrap;
          align-items: center;
          justify-content: center;
          gap: 7px;

          color: #7d847d;

          font-size: 10px;
          line-height: 1.45;
        }

        .site-footer.proper-footer .dot {
          color: #a4a9a2;
        }

        .site-footer.proper-footer .footer-spacer {
          width: 36px;
          height: 36px;
        }

        @media (max-width: 700px) {
          .site-footer.proper-footer {
            width: calc(100% - 20px);
            min-height: 122px;

            margin:
              12px
              10px
              max(
                14px,
                env(safe-area-inset-bottom)
              );

            padding:
              16px
              14px;

            border-radius: 16px;
          }

          .site-footer.proper-footer .footer-inner {
            grid-template-columns:
              34px
              minmax(0, 1fr);

            gap: 11px;
          }

          .site-footer.proper-footer .footer-mark {
            width: 30px;
            height: 30px;
            font-size: 12px;
          }

          .site-footer.proper-footer .footer-center {
            text-align: left;
          }

          .site-footer.proper-footer .footer-sentence {
            font-size: 12px;
            line-height: 1.5;
          }

          .site-footer.proper-footer .footer-meta {
            justify-content: flex-start;

            margin-top: 7px;

            gap: 5px;

            font-size: 9px;
            line-height: 1.5;
          }

          .site-footer.proper-footer .footer-spacer {
            display: none;
          }
        }
      `}</style>
    </>
  );
}
