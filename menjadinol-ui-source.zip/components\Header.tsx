"use client";

import Link from "next/link";
import { usePathname, useSearchParams } from "next/navigation";

import { DateTimeBadge } from "./DateTimeBadge";
import ReaderLogoutButton from "./ReaderLogoutButton";

type ContentSection =
  | "tentang"
  | "layanan"
  | "ruang-belajar"
  | "sinopsis"
  | "artikel"
  | "kontak";

const publicLinks: Array<{
  href: string;
  label: string;
  section?: ContentSection;
}> = [
  {
    href: "/",
    label: "Beranda",
  },
  {
    href: "/tentang",
    label: "Tentang",
    section: "tentang",
  },
  {
    href: "/perjalanan",
    label: "Perjalanan",
    section: "layanan",
  },
  {
    href: "/ruang-belajar",
    label: "Ruang Belajar",
    section: "ruang-belajar",
  },
  {
    href: "/sinopsis",
    label: "Sinopsis",
    section: "sinopsis",
  },
  {
    href: "/artikel",
    label: "Artikel",
    section: "artikel",
  },
  {
    href: "/kontak",
    label: "Kontak",
    section: "kontak",
  },
];

export function Header() {
  const pathname = usePathname();
  const searchParams = useSearchParams();

  /*
   * =========================================================
   * MODE HEADER
   * =========================================================
   *
   * Reader:
   *   route website biasa.
   *
   * Writer:
   *   /writer
   *
   * Admin + Superadmin:
   *   /admin
   *   /admin/*
   *
   * Ini hanya menentukan LINK UI.
   * Otorisasi sebenarnya tetap dilakukan server.
   */
  const isWriterArea =
    pathname === "/writer" ||
    pathname.startsWith("/writer/");

  const isAdminArea =
    pathname === "/admin" ||
    pathname.startsWith("/admin/");

  const activeSection =
    searchParams.get("section");

  function resolveHref(
    publicHref: string,
    section?: ContentSection
  ) {
    /*
     * Beranda tidak dipakai untuk memilih editor.
     */
    if (!section) {
      if (isWriterArea) {
        return "/writer";
      }

      if (isAdminArea) {
        return "/admin";
      }

      return publicHref;
    }

    /*
     * Writer memilih bagian konten dari header asli.
     */
    if (isWriterArea) {
      return `/writer?section=${section}`;
    }

    /*
     * Admin / Superadmin memilih bagian konten
     * dari header asli.
     */
    if (isAdminArea) {
      return `/admin?section=${section}`;
    }

    /*
     * Reader tetap memakai URL website normal.
     */
    return publicHref;
  }

  function isActive(
    publicHref: string,
    section?: ContentSection
  ) {
    if (
      isWriterArea ||
      isAdminArea
    ) {
      if (!section) {
        return false;
      }

      return activeSection === section;
    }

    return pathname === publicHref;
  }

  return (
    <header className="topbar jp-topbar">
      <div className="shell nav jp-main-nav">
        <Link
          className="header-brand"
          href={
            isWriterArea
              ? "/writer"
              : isAdminArea
              ? "/admin"
              : "/"
          }
          aria-label="Jalan Pulang"
        >
          <span className="header-title">
            Jalan Pulang
          </span>

          <span className="header-subtitle">
            kembali ke nol
          </span>
        </Link>

        <nav
          className="menu"
          aria-label="Navigasi utama"
        >
          {publicLinks.map(
            ({
              href,
              label,
              section,
            }) => {
              const resolvedHref =
                resolveHref(
                  href,
                  section
                );

              return (
                <Link
                  key={href}
                  href={resolvedHref}
                  className={
                    isActive(
                      href,
                      section
                    )
                      ? "active"
                      : ""
                  }
                >
                  {label}
                </Link>
              );
            }
          )}
        </nav>

        <div className="reader-logout-slot">
          <ReaderLogoutButton />
        </div>
      </div>

      <div className="jp-time-strip">
        <div className="shell jp-time-strip-inner">
          <DateTimeBadge />
        </div>
      </div>
    </header>
  );
}